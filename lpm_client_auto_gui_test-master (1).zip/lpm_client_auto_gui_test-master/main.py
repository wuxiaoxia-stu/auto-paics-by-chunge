import pyautogui

from setting import ROUND_TOTAL
from testcase.user import testeditusergroup
from testcase.index import testswitchuser
from testcase.analysis import teststartanalysis

if __name__ == "__main__":

    pyautogui.hotkey("alt", "tab")

    i = 10
    while i > 0:

        # testeditusergroup.run()
        #
        # testswitchuser.run()

        teststartanalysis.run()
        i -= 1
