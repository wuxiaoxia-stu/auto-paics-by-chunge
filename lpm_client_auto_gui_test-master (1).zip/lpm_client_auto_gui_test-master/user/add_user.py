import os
import pyautogui
import time
import logging
from datetime import datetime

from setting import BASE_DIR
from common import move_to, has_image, program_exit

if not os.path.exists(os.path.join(BASE_DIR, "log/user")):
    os.makedirs(os.path.join(BASE_DIR, "log/user"))

LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
DATE_FORMAT = "%m/%d/%Y %H:%M:%S %p"

LOG_NAME = "log/user/user" + datetime.now().strftime("%Y%m%d%H%M%S") + ".log"
logging.basicConfig(filename=LOG_NAME, level=logging.DEBUG, format=LOG_FORMAT, datefmt=DATE_FORMAT, filemode='w')


class ModifyUser(object):

    def __init__(self):
        self.screenWidth, self.screenHeight = pyautogui.size()

    # 判断是否插入主任密钥
    def is_insert_leader_key(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/not_insert_leader_key.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            return True, err
        elif temp_x < 0:
            err = "get not insert leader key error!"
            return False, err
        else:
            err = "has not insert leader key"
            return False, err

    # 判断是否插入正确主任用户的主任密钥
    def is_correct_user_leader_key(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/leader_error_user.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            return True, err
        elif temp_x < 0:
            err = "get leader key user correct error!"
            return False, err
        else:
            err = "has leader key user not correct"
            return False, err

    # 一键同步用户信息
    def click_sync_leader_key(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/click_sync.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            return False, err
        elif temp_x < 0:
            err = "get sync button error!"
            return False, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(2)
            return True, err

    # 取消进入修改用户
    def cancel_in_add_user(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/in_add_user_cancel.bmp',
                                                   region=(self.screenWidth * 1//3, self.screenHeight * 1//3,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            return True, err
        elif temp_x < 0:
            err = "get confirm cancel button error!"
            return False, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            return True, err

    # 获取进入新建普通用户界面按钮
    def get_and_in_add_user(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/in_add_user.bmp',
                                                   region=(self.screenWidth * 1//3, self.screenHeight * 1//3,
                                                           self.screenWidth * 2//3, self.screenHeight * 2//3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not in add user icon!'
            return False, err
        elif temp_x < 0:
            err = "get in add user icon error!"
            return False, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(2)
            return True, err

    # 获取新建用户按钮
    # 点击新建普通用户按钮
    def get_create_user_icon(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/add_user.bmp',
                                                   region=(self.screenWidth * 2//3, 0,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not create user icon!'
            return False, err
        elif temp_x < 0:
            err = 'get create user icon error!'
            return False, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(2)
            return True, err

    # 绘制密码
    def drag_password(self):

        err = ""
        result = False
        i = 5
        while i > 0:
            i -= 1
            pos_list = list(pyautogui.locateAllOnScreen('static/add_user/password_icon.bmp'))
            if len(pos_list) > 6:
                move_to(pos_list[0].left + pos_list[0].width // 2, pos_list[0].top + pos_list[0].height // 2)
                pyautogui.mouseDown()
                for pos in pos_list[1:6]:
                    move_to(pos.left + pos.width // 2, pos.top + pos.height // 2)
                pyautogui.mouseUp()
            elif len(pos_list) > 0:
                err = 'drag password error!'
                continue
            else:
                result = True
                break
        return result, err

    # todo 删除用户
    def del_user(self):

        success = False
        tmp_x = 0
        tmp_y = 0
        pos_list = list(pyautogui.locateAllOnScreen('static/add_user/del_user_icon.bmp'))
        if len(pos_list) > 0:
            move_to(pos_list[-1].left + pos_list[-1].width // 2, pos_list[-1].top + pos_list[-1].height // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            tmp_x = pos_list[-1].left
            tmp_y = pos_list[-1].top
        return success, tmp_x, tmp_y

    # todo 确定删除用户
    def del_user_confirm(self, pos_x, pos_y):

        err = ""
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/del_user_confirm.bmp',
                                                   region=(pos_x - 200, pos_y - 200,
                                                           400, 400))
        if temp_x == 0 and temp_y == 0:
            err = 'has not confirm del user button!'
            return False, err
        elif temp_x < 0:
            err = 'get confirm del user button error!'
            return False, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            return True, err

    # todo 取消删除用户
    def del_user_cancel(self, pos_x, pos_y):

        err = ""
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/del_user_cancel.bmp',
                                                   region=(pos_x - 200, pos_y - 200,
                                                           400, 400))
        if temp_x == 0 and temp_y == 0:
            err = 'has not cancel del user button!'
            return False, err
        elif temp_x < 0:
            err = 'get cancel del user button error!'
            return False, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            return True, err

    # 保存修改
    def save_user_modify(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/user_info_save.bmp',
                                                   region=(self.screenWidth * 2//3, self.screenHeight * 2//3,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            err = "has not get save button!"
            return False, err
        elif temp_x < 0:
            err = "get save button error!"
            return False, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            return True, err

    # 取消修改
    def cancel_user_modify(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/user_info_cancel.bmp',
                                                   region=(self.screenWidth * 2//3, self.screenHeight * 2//3,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not get cancel user modify button!'
            return False, err
        elif temp_x < 0:
            err = 'get cancel user modify button error!'
            return False, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(2)
            return True, err

    # 取消修改之取消
    def cancel_user_modify_cancel(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/user_info_cancel_cancel.bmp',
                                                   region=(self.screenWidth * 1//3, self.screenHeight * 1//3,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            return True, err
        elif temp_x < 0:
            err = 'get cancel cancel button error!'
            return False, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            return True, err

    # 取消修改之保存
    def cancel_user_modify_save(self):

        err = ""
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/user_info_cancel_save.bmp',
                                                   region=(self.screenWidth * 1//3, self.screenHeight * 1//3,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not get cancel save button!'
            return False, err
        elif temp_x < 0:
            err = 'get cancel save button error!'
            return False, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            return True, err

    # 修改用户密码
    def get_and_change_user_password(self):

        pyautogui.size()
        err = ""
        success = False
        pos_list = list(pyautogui.locateAllOnScreen('static/add_user/change_pass_icon.bmp'))
        if len(pos_list) > 0:
            move_to(pos_list[-1].left + pos_list[-1].width // 2, pos_list[-1].top + pos_list[-1].height // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success, err

    # 修改用户名
    def change_user_name(self):

        pyautogui.size()
        err = ""
        success = False
        pos_list = list(pyautogui.locateAllOnScreen('static/add_user/change_name_icon.bmp'))
        if len(pos_list) > 0:
            move_to(pos_list[-1].left + pos_list[-1].width // 2, pos_list[-1].top + pos_list[-1].height // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success, err

    # todo 输入名称
    def write_name(self):

        err = ""
        pyautogui.write('test change', interval=0.25)
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/change_name_confirm.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 2 // 3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not get change name confirm icon!'
            return False, err
        elif temp_x < 0:
            err = 'get get change name confirm icon error!'
            return False, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            return True, err

    def handle_cancel_modify(self):
        success, err = self.cancel_user_modify()
        if not success:
            logging.error(err)
            return

        success, err = self.cancel_user_modify_cancel()
        if not success:
            logging.error(err)
        return

    @program_exit
    def run(self, round2):

        save = round2 % 2 == 0   # 当循环为偶数时，点击保存

        # 点击进入创建新用户
        success, err = self.get_and_in_add_user()
        if not success:
            logging.error(err)
            return

        # 判断是否插入主任密钥
        success, err = self.is_insert_leader_key()
        if not success:
            logging.error(err)
            success, err = self.cancel_in_add_user()
            if not success:
                logging.error(err)
                return

        # 判断是否是正确的主任密钥
        success, err = self.is_correct_user_leader_key()
        if not success:
            logging.error(err)
            success, err = self.cancel_in_add_user()
            if not success:
                logging.error(err)
                return

        # 判断是否需要一键同步
        success, err = self.click_sync_leader_key()
        if not success and err != "":
            logging.error(err)
            return

        # 点击创建新用户按钮
        success, err = self.get_create_user_icon()
        if not success:
            logging.error(err)
            self.handle_cancel_modify()
            return

        # 绘制密码
        success, err = self.drag_password()
        if not success:
            logging.error(err)
            self.handle_cancel_modify()
            return

        # 修改密码
        success, err = self.get_and_change_user_password()
        if success:
            # 绘制密码
            success, err = self.drag_password()
            if not success:
                logging.error(err)
                self.handle_cancel_modify()
                return

        # 修改用户姓名
        success, err = self.change_user_name()
        if success:
            success, err = self.write_name()
            if not success:
                logging.error(err)
                self.handle_cancel_modify()
                return

        # 删除用户
        success, pos_x, pos_y = self.del_user()
        if success:
            if save:
                success, err = self.del_user_confirm(pos_x, pos_y)
                if not success:
                    logging.error(err)
                    self.handle_cancel_modify()
                    return
            else:
                success, err = self.del_user_cancel(pos_x, pos_y)
                if not success:
                    logging.error(err)
                    self.handle_cancel_modify()
                    return

        # # 保存修改
        # success, err = self.save_user_modify()
        # if not success:
        #     logging.error(err)
        #     return

        self.handle_cancel_modify()
        logging.info("success!")


if __name__ == "__main__":
    pass
