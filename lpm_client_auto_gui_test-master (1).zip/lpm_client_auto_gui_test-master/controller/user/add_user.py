import pyautogui
import time

from enum import Enum

from controller.common.common import move_to, has_image


# 用户组
class UserGroup(Enum):

    Public = 1
    Private = 2


class ModifyUser(object):
    """
    操作用户
    """

    def __init__(self):
        self.screenWidth, self.screenHeight = pyautogui.size()

    # 获取进入新建普通用户界面按钮
    def get_and_in_add_user(self):
        """
        获取进入新建普通用户界面按钮并点击
        :return: success: 获取按钮是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/in_add_user.bmp',
                                                   region=(self.screenWidth * 1//3, self.screenHeight * 1//3,
                                                           self.screenWidth * 2//3, self.screenHeight * 2//3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not in add user icon!'
            return success, err
        elif temp_x < 0:
            err = "get in add user icon error!"
            return success, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            return success, err

    def get_create_user_icon(self):
        """
        获取新建用户按钮
        :return: success: 获取按钮是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/add_user.bmp',
                                                   region=(self.screenWidth * 2//3, 0,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not create user icon!'
            return success, err
        elif temp_x < 0:
            err = 'get create user icon error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(3)
            success = True
            return success, err

    def del_user(self):
        """
        删除当前页列表最后一个用户
        :return: success: 删除用户是否成功
        :return: tmp_x: 删除按钮坐标left
        :return: tmp_y: 删除按钮坐标top
        """

        success = False
        tmp_x = 0
        tmp_y = 0
        pos_list = list(pyautogui.locateAllOnScreen('static/add_user/del_user_icon.bmp'))
        if len(pos_list) > 0:
            move_to(pos_list[-1].left + pos_list[-1].width // 2, pos_list[-1].top + pos_list[-1].height // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            tmp_x = pos_list[-1].left
            tmp_y = pos_list[-1].top
        time.sleep(1)
        return success, tmp_x, tmp_y

    def del_user_confirm(self, pos_x, pos_y):
        """
        删除用户confirm弹窗，选择确定删除
        :param pos_x: 删除按钮坐标left
        :param pos_y: 删除按钮坐标top
        :return: success: 操作确定按钮是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/del_user_confirm.bmp',
                                                   region=(pos_x - 300, pos_y - 300,
                                                           300, 300))
        if temp_x == 0 and temp_y == 0:
            err = 'has not confirm del user button!'
            return success, err
        elif temp_x < 0:
            err = 'get confirm del user button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
            return success, err

    def del_user_cancel(self, pos_x, pos_y):
        """
        删除用户confirm弹窗，选择取消删除
        :param pos_x: 删除按钮坐标left
        :param pos_y: 删除按钮坐标top
        :return: success: 操作取消按钮是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/del_user_cancel.bmp',
                                                   region=(pos_x - 300, pos_y - 300,
                                                           300, 300))
        if temp_x == 0 and temp_y == 0:
            err = 'has not cancel del user button!'
            return success, err
        elif temp_x < 0:
            err = 'get cancel del user button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
            return success, err

    def save_user_modify(self):
        """
        保存修改
        :return: success: 操作保存修改按钮是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/user_info_save.bmp',
                                                   region=(self.screenWidth * 2//3, self.screenHeight * 2//3,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            err = "has not get save button!"
            return success, err
        elif temp_x < 0:
            err = "get save button error!"
            return success, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(2)
            success = True
            return success, err

    def cancel_user_modify(self):
        """
        取消修改
        :return: success: 操作取消修改按钮是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/user_info_cancel.bmp',
                                                   region=(self.screenWidth * 2//3, self.screenHeight * 2//3,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not get cancel user modify button!'
            return success, err
        elif temp_x < 0:
            err = 'get cancel user modify button error!'
            return success, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(2)
            success = True
            return success, err

    # 取消修改之取消
    def cancel_user_modify_cancel(self):
        """
        取消修改之confirm弹窗之取消按钮
        :return: success: 操作按钮是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/user_info_cancel_cancel.bmp',
                                                   region=(self.screenWidth * 1//3, self.screenHeight * 1//3,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            success = True
            return success, err
        elif temp_x < 0:
            err = 'get cancel cancel button error!'
            return success, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(2)
            success = True
            return success, err

    # 取消修改之保存
    def cancel_user_modify_save(self):
        """
        取消修改之confirm弹窗之确定按钮
        :return: success: 操作按钮是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/user_info_cancel_save.bmp',
                                                   region=(self.screenWidth * 1//3, self.screenHeight * 1//3,
                                                           self.screenWidth * 1//3, self.screenHeight * 1//3))
        if temp_x == 0 and temp_y == 0:
            success = True
            return success, err
        elif temp_x < 0:
            err = 'get cancel save button error!'
            return success, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(4)
            success = True
            return success, err

    def get_and_change_user_password(self):
        """
        修改用户密码: 点击当前页最后一个可以修改密码的icon
        :return: success: 操作icon是否成功
        """

        pyautogui.size()
        success = False
        pos_list = list(pyautogui.locateAllOnScreen('static/add_user/change_pass_icon.bmp'))
        if len(pos_list) > 0:
            move_to(pos_list[-1].left + pos_list[-1].width // 2, pos_list[-1].top + pos_list[-1].height // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success

    def change_user_name(self):
        """
        修改用户名: 点击当前页最后一个可以修改用户名的icon
        :return: success: 操作icon是否成功
        """

        pyautogui.size()
        success = False
        pos_list = list(pyautogui.locateAllOnScreen('static/add_user/change_name_icon.bmp'))
        if len(pos_list) > 0:
            move_to(pos_list[-1].left + pos_list[-1].width // 2, pos_list[-1].top + pos_list[-1].height // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success

    def write_name(self, name):
        """
        输入名称，并点击确定
        :param name: 用户姓名
        :return: success: 修改名称是否成功
        """

        err = ""
        success = False
        pyautogui.write(name, interval=0.25)
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/change_name_confirm.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 2 // 3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not get change name confirm icon!'
            return success, err
        elif temp_x < 0:
            err = 'get get change name confirm icon error!'
            return success, err
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            success = True
            return success, err

    def handle_cancel_modify(self):
        """
        处理取消修改
        :return: err: 错误信息
        """

        success, err = self.cancel_user_modify()
        if not success:
            return err

        success, err = self.cancel_user_modify_cancel()
        return err

    def modify_group(self):
        """
        切换用户组
        :return: success 切换是否成功
        """

        pyautogui.size()
        success = False
        pos_list = list(pyautogui.locateAllOnScreen('static/add_user/modify_group.bmp'))
        if len(pos_list) > 0:
            move_to(pos_list[-1].left + pos_list[-1].width // 2, pos_list[-1].top + pos_list[-1].height // 2)
            pyautogui.click()
            time.sleep(0.5)
            success = True
            active_group = self.is_private_group()
            move_y = 42
            if active_group == UserGroup.Public:
                move_y = 92
            move_to(pos_list[-1].left + pos_list[-1].width // 2 , pos_list[-1].top + pos_list[-1].height // 2 + move_y)
            pyautogui.click()
            time.sleep(0.5)
        return success

    # 判断用户是否是独立组
    def is_private_group(self):
        """
        判断用户是否是独立组
        :return: user_group - UserGroup
        """

        pyautogui.size()
        user_group = UserGroup.Public
        pos_list = list(pyautogui.locateAllOnScreen('static/add_user/private_group_active.bmp'))
        if len(pos_list) > 0:
            user_group = UserGroup.Private
        return user_group

    # 判断操作成功
    def operation_success(self):
        """
        判断操作成功
        :return: success: 判断操作成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        temp_x, temp_y, temp_w, temp_h = has_image('static/add_user/modify_success.bmp',
                                                   region=(self.screenWidth * 1 // 2 - 200, 0,
                                                           self.screenWidth * 1 // 2 + 200, 100))
        if temp_x == 0 and temp_y == 0:
            err = 'has not modify success icon!'
        if temp_x < 0:
            err = 'get get modify success icon error!'
        elif temp_x > 0:
            success = True
        return success, err


add_user_handle = ModifyUser()


if __name__ == "__main__":
    pass
