import time
import pyautogui

from controller.common.common import move_to, has_image


class LeaderKey(object):
    """
    操作主任密钥
    """

    def __init__(self):
        self.screenWidth, self.screenHeight = pyautogui.size()

    def is_insert_leader_key(self):
        """
        判断是否插入主任密钥
        :return: success: 是否插入了主任密钥
        :return: err string: 错误信息
        """

        err = ""
        success = False

        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/leader_key/not_insert_leader_key.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            success = True
        elif temp_x < 0:
            err = "get not insert leader key error!"
        else:
            err = "has not insert leader key"
        return success, err

    def is_correct_user_leader_key(self):
        """
        判断是否插入正确主任用户的主任密钥
        :return: success: 是否插入了正确主任密钥
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/leader_key/leader_error_user.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            success = True
        elif temp_x < 0:
            err = "get leader key user correct error!"
        else:
            err = "has leader key user not correct"
        return success, err

    def is_valid_leader_key(self):
        """
        判断是否插入合法的主任密钥
        :return: success: 判断插入的主任密钥是否为合法的
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/leader_key/invalid_leader_key.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            success = True
        elif temp_x < 0:
            err = "get invalid leader key error!"
        else:
            err = "has invalid leader key correct"
        return success, err

    def click_sync_leader_key(self):
        """
        一键同步用户信息
        :return: success: 一键同步用户信息是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/leader_key/click_sync.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x == 0:
            success = True
        elif temp_x < 0:
            err = "get sync button error!"
        else:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success, err

    def re_try(self):
        """
        重试
        :return: success: 重试是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/leader_key/re-try.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x < 0:
            err = "get sync button error!"
        elif temp_x > 0:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success, err

    def cancel(self):
        """
        confirm弹窗点击取消
        :return: success: 取消是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/leader_key/cancel.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x < 0:
            err = "get sync button error!"
        elif temp_x > 0:
            move_to(temp_x + temp_w / 2, temp_y + temp_h / 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success, err

    def handle_leader_key_valid(self):
        """
        判断主任密钥是否正确
        :return: success: 主任密钥是否正确
        :return: err: 错误信息
        """

        # 判断是否插入主任密钥
        success, err = self.is_insert_leader_key()
        if not success:
            success, err = self.cancel()
            return False, err

        # 判断是否合法的主任密钥
        success, err = self.is_valid_leader_key()
        if not success:
            success, err = self.cancel()
            return False, err

        # 判断是否是正确的主任密钥
        success, err = self.is_correct_user_leader_key()
        if not success:
            success, err = self.cancel()
            return False, err
        return success, err


leader_key_handle = LeaderKey()
