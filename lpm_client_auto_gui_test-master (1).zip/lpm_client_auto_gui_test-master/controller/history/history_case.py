import os
import time
import pyautogui

from controller.common.common import has_image, move_to


class HistoryCase(object):
    """
    历史病例
    """

    def __init__(self):
        self.screenWidth, self.screenHeight = pyautogui.size()

    def exit_case(self):
        """
        退出病例
        :return: success: 退出病例是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()

        temp_x, temp_y, temp_w, temp_h = has_image('static/history/exit_case.bmp',
                                                   region=(self.screenWidth - 400, self.screenHeight - 300, 400, 300))
        if temp_x == 0 and temp_y == 0:
            err = 'has not exit button!'
        elif temp_x < 0:
            err = 'get stop exit button error!'
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success, err


history_case_handle = HistoryCase()
