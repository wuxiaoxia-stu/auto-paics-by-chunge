import os
import time
import pyautogui
from enum import Enum

from controller.common.common import has_image, move_to


# ai 开关
class AiSwitch(Enum):
    On = 1
    Off = 2


AiSwitchDict = {AiSwitch.On: "ai_on.bmp", AiSwitch.Off: "ai_off.bmp"}


class PlayControl(object):
    """
    播放器控制
    """

    def __init__(self):
        self.screenWidth, self.screenHeight = pyautogui.size()

    def get_ai_switch(self):
        """
        获取病例分析中的ai开关
        :return: ai_position: ai开关坐标
        :return: ai_switch_status: ai开关状态 - AiSwitch
        :return: err: 错误信息
        """

        err = ""
        pyautogui.size()
        ai_position = None
        ai_switch_status = None

        for item in AiSwitch:
            ai_switch_status = item
            temp_x, temp_y, temp_w, temp_h = has_image(os.path.join('static/play_control', AiSwitchDict[item]),
                                                       region=(self.screenWidth * 1 // 2, self.screenHeight - 400,
                                                               self.screenWidth,
                                                               400))
            if temp_x == 0 and temp_y == 0:
                err = 'has not ai switch icon!'
                continue
            elif temp_x < 0:
                err = 'get ai switch icon error!'
                break
            else:
                ai_position = [temp_x, temp_y, temp_w, temp_w]
                break
        if not ai_position:
            self.get_case_control()
            return self.get_ai_switch()
        return ai_position, ai_switch_status, err

    def turn_ai_switch(self, ai_position):
        """
        开、关ai开关
        :param ai_position: ai开关位置坐标
        :return:
        """

        move_to(ai_position[0] + ai_position[2] // 2, ai_position[1] + ai_position[3] // 2)
        pyautogui.click()
        time.sleep(1)

    def get_case_setting(self):
        """
        病例分析中下拉呼出菜单
        :return:
        """
        move_to(self.screenWidth * 1 // 2, 0)
        pyautogui.mouseDown()
        move_to(self.screenWidth * 1 // 2, 80)
        pyautogui.mouseUp()
        return

    def get_case_control(self):
        """
        呼出播放控制
        :return:
        """

        move_to(self.screenWidth * 1 // 2, self.screenHeight * 1 // 2)
        pyautogui.click()
        time.sleep(0.5)

    def screenshot(self):
        """
        截图
        :return: success: 操作截图是否成功
        :return: err: 错误信息
        """

        self.get_case_setting()

        err = ""
        success = False
        pyautogui.size()

        temp_x, temp_y, temp_w, temp_h = has_image('static/play_control/screenshot.bmp',
                                                   region=(self.screenWidth * 1 // 2 - 300, 0,
                                                           self.screenWidth * 1 // 2 + 200, 100))
        if temp_x == 0 and temp_y == 0:
            err = 'has not screenshot icon!'
        elif temp_x < 0:
            err = 'get screenshot icon error!'
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
        return success, err

    def back_analysis(self):
        """
        返回分析
        :return: success: 操作返回分析是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()

        temp_x, temp_y, temp_w, temp_h = has_image('static/play_control/back_analysis.bmp',
                                                   region=(self.screenWidth * 1 // 3 - 100,
                                                           self.screenHeight * 1 // 2 - 200, self.screenWidth,
                                                           self.screenHeight * 1 // 2 + 200))
        if temp_x == 0 and temp_y == 0:
            err = 'has not back analysis button!'
            return success, err
        elif temp_x < 0:
            err = 'get back analysis button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            return success, err


play_control_handler = PlayControl()
