import os
import time
import pyautogui
from enum import Enum

from controller.common.common import has_image, move_to


# 筛查设置枚举
class ScreeningType(Enum):

    TypeA = 1
    TypeB = 2
    TypeC = 3


ScreeningTypeDict = {ScreeningType.TypeA: "screening_a.bmp", ScreeningType.TypeB: "screening_b.bmp",
                     ScreeningType.TypeC: "screening_c.bmp"}
MultiScreeningTypeDict = {ScreeningType.TypeA: "multi_case_screening_a.bmp",
                          ScreeningType.TypeB: "multi_case_screening_b.bmp",
                          ScreeningType.TypeC: "multi_case_screening_c.bmp"}


# 病例类型
class CaseType(Enum):

    Single = 1  # 单胎
    Multi = 2   # 多胎
    Continue = 3    # 续接


CaseTypeDict = {CaseType.Single: "", CaseType.Multi: "multi_case.bmp", CaseType.Continue: "continue_case.bmp"}


# 多胎
class CaseMultiF(Enum):

    F1 = 1
    F2 = 2
    F3 = 3


CaseMultiFDict = {CaseMultiF.F1: "f1.bmp", CaseMultiF.F2: "f2.bmp", CaseMultiF.F3: "f3.bmp"}


class StartAnalysis(object):
    """
    处理病例开始分析与结束分析
    """

    def __init__(self):
        self.screenWidth, self.screenHeight = pyautogui.size()
        self.caseSelectTop = 109
        self.caseTableRowHeight = 82

    # 开始检查设置病例
    def start_analysis_by_screening_type(self, screening_type):
        """
        开始某一筛查设置的病例分析
        :param screening_type: 筛查类型 - ScreeningType
        :return: success: 开始分析是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image(os.path.join('static/analysis', ScreeningTypeDict[screening_type]),
                                                   region=(100, self.screenHeight * 1 // 3, self.screenWidth - 100,
                                                           self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not screening type button!'
            return success, err
        elif temp_x < 0:
            err = 'get screening type button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            return success, err

    # 选择开始病例的类型
    def select_start_case_type(self, case_type):
        """
        选择某一类型（单胎、多胎、续接）的病例分析
        :param case_type: 病例类型 - CaseType
        :return: success: 开始分析是否成功
        :return: err: 错误信息
        """

        success = False
        err = ""
        if case_type == CaseType.Single:
            success = True
            return success, err

        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image(os.path.join('static/analysis', CaseTypeDict[case_type]),
                                                   region=(0, 0, self.screenWidth * 1 // 2, self.screenHeight * 1 // 2))
        if temp_x == 0 and temp_y == 0:
            err = 'has not case type button!'
            return success, err
        elif temp_x < 0:
            err = 'get case type button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            return success, err

    # 开始多胎
    def get_and_start_multi_case(self):
        """
        开始多胎的病例分析
        :return: success: 开始分析是否成功
        :return: multi_f: 第几胎 - CaseMultiF
        :return: err: 错误信息
        """

        err = ""
        multi_f = 0
        success = False
        pyautogui.size()

        for item in CaseMultiF:

            multi_f = item
            temp_x, temp_y, temp_w, temp_h = has_image(os.path.join('static/analysis', CaseMultiFDict[item]),
                                                       region=(self.screenWidth * 1 // 3, self.screenHeight * 2 // 3,
                                                               self.screenWidth * 2 // 3, self.screenHeight))
            if temp_x == 0 and temp_y == 0:
                err = 'has not case type button!'
                continue
            elif temp_x < 0:
                err = 'get case type button error!'
                break
            else:
                move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
                pyautogui.click()
                time.sleep(1)
                success = True
                break
        return success, multi_f, err

    def multi_case_select_case(self):
        """
        多胎选择病例
        1、是否有选中的病例
        2、没有选中的，是否有可选的，有则选择第一个可选的
        :return:
        """

        pyautogui.size()
        selected_list = list(pyautogui.locateAllOnScreen('static/analysis/selected.bmp'))
        if len(selected_list) > 0:
            return

        selected_list = list(pyautogui.locateAllOnScreen('static/analysis/select.bmp'))
        if len(selected_list) > 0:
            move_to(selected_list[0].left + selected_list[0].width // 2,
                    selected_list[0].top + selected_list[0].height // 2)
            pyautogui.click()
            time.sleep(1)
        return

    # 多胎选择筛查类型
    def multi_case_select_screening(self, screening_type):
        """
        多胎f1时选择筛查类型
        :param screening_type: 筛查类型 - ScreeningType
        :return: success: 选择筛查类型是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image(os.path.join('static/analysis',
                                                                MultiScreeningTypeDict[screening_type]),
                                                   region=(100, self.screenHeight * 1 // 3, self.screenWidth - 100,
                                                           self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not screening type button!'
            return success, err
        elif temp_x < 0:
            err = 'get screening type button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            return success, err

    def start_continue_case_confirm(self):
        """
        开始续接病例
        :return: success: 开始续接是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/analysis/continue_confirm.bmp',
                                                   region=(self.screenWidth * 1//2 + 100, self.screenHeight * 2 // 3,
                                                           self.screenWidth * 1//3 + 200,
                                                           self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not continue confirm button!'
        elif temp_x < 0:
            err = 'get continue confirm button error!'
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
        return success, err

    # 结束检查
    def stop_analysis(self):
        """
        结束检查
        :return: success: 结束检查是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()

        temp_x, temp_y, temp_w, temp_h = has_image('static/analysis/stop_analysis.bmp',
                                                   region=(self.screenWidth - 400, self.screenHeight - 300, 400, 300))
        if temp_x == 0 and temp_y == 0:
            err = 'has not stop analysis button!'
            return success, err
        elif temp_x < 0:
            err = 'get stop analysis button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
            return success, err

    def skip_countdown(self):
        """
        跳过倒计时
        :return: success: 操作跳过倒计时是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()

        temp_x, temp_y, temp_w, temp_h = has_image('static/analysis/skip_countdown.bmp',
                                                   region=(self.screenWidth * 1 // 3, 0, self.screenWidth * 1 // 3,
                                                           self.screenHeight * 1 // 2))
        if temp_x == 0 and temp_y == 0:
            err = 'has not skip countdown button!'
            return success, err
        elif temp_x < 0:
            err = 'get skip countdown button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            return success, err

    def skip_wait_continue(self):
        """
        跳过结束简略页
        :return: success: 操作跳过结束简略页是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()

        temp_x, temp_y, temp_w, temp_h = has_image('static/analysis/skip.bmp',
                                                   region=(self.screenWidth * 1 // 3, 0, self.screenWidth * 1 // 3,
                                                           self.screenHeight * 1 // 2))
        if temp_x == 0 and temp_y == 0:
            err = 'has not skip button!'
            return success, err
        elif temp_x < 0:
            err = 'get skip button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            return success, err

    def mark_to_be_continue(self):
        """
        标记为待续接
        :return: success: 操作标记为待续接是否成功
        :return: err: 错误信息
        """
        err = ""
        success = False
        pyautogui.size()

        temp_x, temp_y, temp_w, temp_h = has_image('static/analysis/mark_to_be_continue.bmp',
                                                   region=(self.screenWidth * 1 // 3, 0, self.screenWidth * 1 // 3,
                                                           self.screenHeight * 1 // 2))
        if temp_x == 0 and temp_y == 0:
            err = 'has not mark to be continue button!'
            return success, err
        elif temp_x < 0:
            err = 'get mark to be continue button error!'
            return success, err
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
            return success, err

    def scroll_to_stop_skip(self):
        """
        滚动鼠标，防止倒计时结束自动跳转
        :return:
        """

        move_to(self.screenWidth * 1 // 3, self.screenHeight * 4 // 5)

        i = 40
        while True:
            pyautogui.scroll(10)
            pyautogui.scroll(-10)
            time.sleep(0.3)
            i -= 1
            if i < 0:
                break

    def is_have_else_multi_case(self):
        """
        是否有关联其他多胎
        :return: success: 操作标记为待续接是否成功
        :return: err: 错误信息
        :return: pos_x: icon的坐标left
        :return: pos_y: icon的坐标top
        """

        err = ""
        success = False
        pos_x = 0
        pos_y = 0
        pyautogui.size()

        temp_x, temp_y, temp_w, temp_h = has_image('static/analysis/multi_case_change.bmp',
                                                   region=(self.screenWidth * 1 // 2 - 200, 0, 300, 100))
        if temp_x == 0 and temp_y == 0:
            err = 'has not else multi case icon!'
        elif temp_x < 0:
            err = 'get else multi case icon error!'
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pos_x = temp_x
            pos_y = temp_y
            pyautogui.click()
            time.sleep(1)
            success = True
        return success, pos_x, pos_y, err

    def switch_multi_case(self, multi_f, pos_x, pos_y):
        """
        切换到目标关联多胎
        :param multi_f: CaseMultiF 需要切换的目标多胎病例
        :param pos_x:  icon的坐标left
        :param pos_y:  icon的坐标top
        :return:
        """

        height = 80
        if multi_f == CaseMultiF.F2:
            height += 58
        elif multi_f == CaseMultiF.F3:
            height += 58 * 2
        move_to(pos_x, pos_y + height)
        pyautogui.click()
        time.sleep(0.5)

    def switch_multi_case_confirm(self):
        """
        切换到目标关联多胎,confirm弹窗确定
        :return: success: 操作confirm弹窗确定是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()

        temp_x, temp_y, temp_w, temp_h = has_image('static/analysis/multi_case_change_confirm.bmp',
                                                   region=(self.screenWidth * 1 // 3, self.screenHeight * 1 // 3,
                                                           self.screenWidth * 1 // 3, self.screenHeight * 1 // 3))
        if temp_x == 0 and temp_y == 0:
            err = 'has not else multi case confirm button!'
        elif temp_x < 0:
            err = 'get else multi case confirm button error!'
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
        return success, err


analysis_handle = StartAnalysis()


if __name__ == "__main__":

    for i in CaseMultiF:
        print(i)
