import os
import time
import pyautogui

from controller.common.common import has_image, move_to
from setting import DEFAULT_ACTIVE_USER_WIDTH, DEFAULT_ACTIVE_USER_HEIGHT, UserGroup, UserGroupImgDict


class LoginHandler(object):
    """
    用户登录
    """

    def __init__(self):
        self.screenWidth, self.screenHeight = pyautogui.size()
        self.halfActiveWidth = DEFAULT_ACTIVE_USER_WIDTH * 1//2
        self.activeUserTop = 160
        self.intoSystemTop = DEFAULT_ACTIVE_USER_HEIGHT + self.activeUserTop

    def get_active_user_type(self):
        """
        获取选中用户的所属组类型
        :return: group_type: UserGroup，当返回为0时，为获取错误
        :return: err: 错误信息
        """

        err = ""
        pyautogui.size()
        group_type = 0
        for item in UserGroup:
            temp_x, temp_y, temp_w, temp_h = has_image(os.path.join('static/index', UserGroupImgDict[item]),
                                                       region=(self.screenWidth * 1//2 - self.halfActiveWidth,
                                                               self.activeUserTop, DEFAULT_ACTIVE_USER_WIDTH + 50,
                                                               self.screenHeight * 2//5))
            if temp_x == 0 and temp_y == 0:
                continue
            elif temp_x < 0:
                err = 'get create user icon error!'
                continue
            else:
                group_type = item
                break
        return group_type, err

    def has_next_user(self, left):
        """
        选中用户旁边是否还有用户
        :param left: True-判断左边; False-判断右边
        :return: success: 是否有其它用户
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        pos_x = self.screenWidth * 1 // 2 - DEFAULT_ACTIVE_USER_WIDTH
        width_x = self.halfActiveWidth
        if not left:
            pos_x = self.screenWidth * 1 // 2 + self.halfActiveWidth
            width_x = DEFAULT_ACTIVE_USER_WIDTH + 100
        temp_x, temp_y, temp_w, temp_h = has_image('static/index/has_next.bmp',
                                                   region=(pos_x, self.activeUserTop, width_x, 200))
        if temp_x < 0:
            err = 'get has next user icon error!'
        elif temp_x > 0:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(1)
            success = True
        return success, err

    def get_and_in_system(self):
        """
        进入系统
        :return: success: 进入系统是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/index/into_system.bmp',
                                                   region=(self.screenWidth * 1//2 - self.halfActiveWidth,
                                                           self.intoSystemTop, self.screenWidth, 200))
        if temp_x == 0 and temp_y == 0:
            err = 'has not into system button!'
        elif temp_x < 0:
            err = 'get into system button error!'
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success, err

    def get_and_change_password(self):
        """
        点击修改密码
        :return: success: 点击修改密码是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/index/forget_password.bmp',
                                                   region=(self.screenWidth * 1//2 - 200,
                                                           self.screenHeight * 1//2, 400, self.screenHeight * 1//2))
        if temp_x == 0 and temp_y == 0:
            err = 'has not forget password button!'
        elif temp_x < 0:
            err = 'get forget password button error!'
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success, err

    def cancel(self):
        """
        取消修改或取消登录
        :return: success: 点击取消是否成功
        :return: err: 错误信息
        """

        err = ""
        success = False
        pyautogui.size()
        temp_x, temp_y, temp_w, temp_h = has_image('static/index/cancel.bmp',
                                                   region=(self.screenWidth * 1//2 - 200,
                                                           self.screenHeight * 1//2, 400, self.screenHeight * 1//2))
        if temp_x == 0 and temp_y == 0:
            err = 'has not cancel button!'
        elif temp_x < 0:
            err = 'get cancel button error!'
        else:
            move_to(temp_x + temp_w // 2, temp_y + temp_h // 2)
            pyautogui.click()
            time.sleep(2)
            success = True
        return success, err

    def logout(self):
        """
        退出登录
        :return: success: 退出登录是否成功
        :return: err: 错误信息
        """

        err = ""
        pyautogui.size()
        move_to(self.screenWidth - 60, 30)
        pyautogui.click()
        time.sleep(0.5)
        move_to(self.screenWidth - 60, 110)
        pyautogui.click()
        time.sleep(1)
        success = True
        return success, err


login_handler = LoginHandler()
