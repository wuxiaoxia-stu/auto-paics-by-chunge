#### 环境
python version 3.7

##### 虚拟环境（选用）
* pip install virtualenv 或 python -m pip install virtualenv
* 切换到工作目录，执行virtualenv venv
* 进入虚拟环境 
    * windows终端执行: venv\\Scripts\\activate.bat
    * linux终端执行：source venv/Scripts/activate
##### 安装依赖
pip install -r requirements.txt

##### 执行（需以管理员身份运行终端）
例：python main.py
