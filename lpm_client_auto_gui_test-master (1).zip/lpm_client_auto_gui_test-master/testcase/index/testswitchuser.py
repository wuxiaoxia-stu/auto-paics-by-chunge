import os
import time
import logging

import logging.config as logging_config

from controller.index.login import login_handler
from controller.user.leader_key import leader_key_handle
from controller.common.common import program_exit, drag_password
from setting import BASE_DIR, UserGroup, PASSWORD_INDEX

from settings.log_config import my_log

if not os.path.exists(os.path.join(BASE_DIR, "log")):
    os.makedirs(os.path.join(BASE_DIR, "log"))

logging_config.dictConfig(my_log)
logger = logging.getLogger('testcase.index.testswitchuser')


# 处理查找下一个
def handle_search_next(target_group, left):
    """
    处理查找下一个是否是目标用户组
    :param target_group: UserGroup
    :param left: True-查找左边，False-查找右边
    :return: success: 是否查找到
    :return: err: 错误信息
    """

    err = ""
    success = True
    while success:
        success, err = login_handler.has_next_user(left)
        if err != "":
            return success, err
        if not success:
            return success, err
        group_type, err = login_handler.get_active_user_type()
        if group_type == target_group:
            return success, ""
        elif err != "":
            return success, err
        elif group_type == 0:
            err = "not find any user!"
            return success, err
    return success, err


def search_one_user_by_group(target_group):
    """
    查找特定用户组用户
    :param target_group: UserGroup
    :return: success: 是否查找到
    :return: err: 错误信息
    """

    left = True
    success, err = handle_search_next(target_group, left)
    if not success and err != "":
        return success, err
    if success:
        return success, err
    left = False
    success, err = handle_search_next(target_group, left)
    return success, err


def handle_change_password_login():
    """
    处理独立组用户登录时修改密码
    :return:
    """

    # 点击忘记密码
    success, err = login_handler.get_and_change_password()
    if not success:
        logger.error(err)
        success, err = login_handler.cancel()
        return False, err

    # 修改密码
    success = False
    while not success:
        success, err = drag_password(PASSWORD_INDEX)
        if not success and err != "":
            logger.error(err)
            err = login_handler.cancel()
            if err != "":
                logger.error(err)
            return

    time.sleep(2)
    # 绘制密码
    success = False
    while not success:
        success, err = drag_password(PASSWORD_INDEX)
        if not success and err != "":
            logger.error(err)
            success, err = login_handler.cancel()
            return False, err
    return True, ""


# 处理公开组用户登录
def handle_public_user_login():
    pass


def user_login(user_group, modify_pass=False):
    """
    处理用户登录
    :param user_group: 用户组
    :param modify_pass: 修改用户密码, default: False
    :return: err: 错误信息
    :return: success: 是否成功
    """

    success = False
    group_type, err = login_handler.get_active_user_type()
    if err != "":
        logger.error(err)
        return success, err
    elif group_type == 0:
        logger.error("not find any user!")
        return success, err

    if group_type != user_group:
        success, err = search_one_user_by_group(user_group)
        if err != "":
            logging.error(err)
            return success, err
        if not success:
            logger.error("not find any user!")
            return success, err

    # 点击进入系统
    success, err = login_handler.get_and_in_system()
    if not success:
        logger.error(err)
        return success, err

    if user_group == UserGroup.MANAGE_GROUP:    # 主任登录
        success, err = leader_key_handle.handle_leader_key_valid()
        if not success:
            if err != "":
                logger.error(err)
            return success, err
    elif user_group == UserGroup.PRIVATE_GROUP:     # 独立组用户登录
        if modify_pass:
            success, err = handle_change_password_login()
            if not success:
                logger.error(err)
                login_handler.cancel()
                return success, err
        else:
            # 绘制密码
            success = False
            while not success:
                success, err = drag_password(PASSWORD_INDEX, 2)
                if not success and err != "":
                    logger.error(err)
                    login_handler.cancel()
                    return success, err

    success, err = login_handler.logout()
    if not success:
        logger.error(err)
        return success, err

    success = True
    return success, err


@program_exit
def test_manager_login():
    """
    1.切换选中用户类型为管理员的用户
    2.插入主任密钥情况下点击进入系统
    """
    res = ["""
    1.切换选中用户类型为管理员的用户
    2.插入主任密钥情况下点击进入系统
    """]
    success, err = user_login(UserGroup.MANAGE_GROUP)
    if success:
        res.append("测试成功")
    else:
        res.append(err)
    return res


@program_exit
def test_public_login():
    """
    1.选中用户类型为公开组的用户，点击进入系统
    """

    res = ["""
        1.选中用户类型为公开组的用户，点击进入系统
        """]
    success, err = user_login(UserGroup.PUBLIC_GROUP)
    if success:
        res.append("测试成功")
    else:
        res.append(err)
    return res


@program_exit
def test_private_login():
    """
    1.切换选中用户类型为独立组的用户
    2.点击进入系统
    3.输入正确的手势密码
    """

    res = ["""
        1.切换选中用户类型为独立组的用户
        2.点击进入系统
        3.输入正确的手势密码
        """]
    success, err = user_login(UserGroup.PRIVATE_GROUP)
    if success:
        res.append("测试成功")
    else:
        res.append(err)
    return res


@program_exit
def test_modify_pass_login():
    """
    1.切换选中用户类型为独立组的用户
    2.点击进入系统
    3.插入主任密钥情况下点击忘记密码
    4.修改手势密码成功
    """
    res = ["""
            1.切换选中用户类型为独立组的用户
            2.点击进入系统
            3.插入主任密钥情况下点击忘记密码
            4.修改手势密码成功
            """]
    success, err = user_login(UserGroup.PRIVATE_GROUP, True)
    if success:
        res.append("测试成功")
    else:
        res.append(err)
    return res


def run():

    # 公开组用户登录
    test_public_login()

    # 管理员用户登录
    test_manager_login()

    # 独立组用户登录
    test_private_login()

    # 独立组用户修改密码登录
    test_modify_pass_login()
