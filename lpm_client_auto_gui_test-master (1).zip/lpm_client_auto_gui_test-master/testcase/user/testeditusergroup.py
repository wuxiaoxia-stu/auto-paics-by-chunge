import os
import time
import logging

from datetime import datetime
import logging.config as logging_config

from controller.user.leader_key import leader_key_handle
from controller.user.add_user import add_user_handle
from controller.common.common import program_exit, drag_password
from setting import BASE_DIR, PASSWORD_INDEX

from settings.log_config import my_log

if not os.path.exists(os.path.join(BASE_DIR, "log")):
    os.makedirs(os.path.join(BASE_DIR, "log"))

logging_config.dictConfig(my_log)
logger = logging.getLogger('testcase.user.testeditusergroup')

USER_NAME_PREFIX = "lpm"


def check_leader_key():
    """
    校验主任密钥是否正确
    :return: success: 是否正确
    """

    # 点击进入创建新用户
    success, err = add_user_handle.get_and_in_add_user()
    if not success:
        logger.error(err)
        return success, err
    time.sleep(2.5)
    # 主任密钥是否合法
    success, err = leader_key_handle.handle_leader_key_valid()
    if not success:
        if err != "":
            logger.error(err)
        return success, err

    # 判断是否需要一键同步
    success, err = leader_key_handle.click_sync_leader_key()
    if not success and err != "":
        logger.error(err)
    return success, err


@program_exit
def test_cancel_modify(do_save):
    """
    1.修改编辑任意内容包括：切换所在组、修改名称、修改手势密码、删除后点击取消按钮
    2.点击弹窗取消按钮或点击弹窗保存按钮"
    :param do_save: True-点击弹窗保存按钮；False-点击弹窗取消按钮
    """

    res = [
        """
        1.修改编辑任意内容包括：切换所在组、修改名称、修改手势密码、删除后点击取消按钮
        2.点击弹窗取消按钮或点击弹窗保存按钮"
        """
    ]
    # 验证主任密钥
    success, err = check_leader_key()
    if not success:
        res.append(err)
        return res

    # 修改密码
    success = add_user_handle.get_and_change_user_password()
    if success:
        # 绘制密码
        success = False
        while not success:
            success, err = drag_password(PASSWORD_INDEX)
            if not success and err != "":
                logger.error(err)
                res.append(err)
                err = add_user_handle.handle_cancel_modify()
                if err != "":
                    logger.error(err)
                return res

    # 修改用户姓名
    success = add_user_handle.change_user_name()
    if success:
        success, err = add_user_handle.write_name(USER_NAME_PREFIX + datetime.now().strftime("%H%M%S"))
        if not success:
            logger.error(err)
            res.append(err)
            err = add_user_handle.handle_cancel_modify()
            if err != "":
                logger.error(err)
            return res

    # 删除用户
    success, pos_x, pos_y = add_user_handle.del_user()
    if success:
        success, err = add_user_handle.del_user_confirm(pos_x, pos_y)
        if not success:
            logger.error(err)
            res.append(err)
            err = add_user_handle.handle_cancel_modify()
            if err != "":
                logger.error(err)
            return res

    success, err = add_user_handle.cancel_user_modify()
    if not success:
        logger.error(err)
        res.append(err)
        return res

    if do_save:
        success, err = add_user_handle.cancel_user_modify_save()
    else:
        success, err = add_user_handle.cancel_user_modify_cancel()
    if not success:
        logger.error(err)
        res.append(err)
        return res
    res.append("测试成功")
    return res


@program_exit
def test_create_user():
    """
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.点击“添加新用户”按钮
    3.绘制两次手势密码成功
    4.点击保存按钮"
    """

    res = ["""
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.点击“添加新用户”按钮
    3.绘制两次手势密码成功
    4.点击保存按钮"
    """]
    # 验证主任密钥
    success, err = check_leader_key()
    if not success:
        res.append(err)
        return res

    # 点击创建新用户按钮
    success, err = add_user_handle.get_create_user_icon()
    if not success:
        logger.error(err)
        res.append(err)
        err = add_user_handle.handle_cancel_modify()
        if err != "":
            logger.error(err)
        return res

    # 绘制密码
    success = False
    while not success:
        success, err = drag_password(PASSWORD_INDEX)
        if not success and err != "":
            logger.error(err)
            res.append(err)
            err = add_user_handle.handle_cancel_modify()
            if err != "":
                logger.error(err)
            return res

    # 是否新建成功
    success, err = add_user_handle.operation_success()
    if success:
        logger.info("新建用户成功")
    else:
        logger.error(err)
        res.append(err)
        err = add_user_handle.handle_cancel_modify()
        if err != "":
            logger.error(err)
        return res

    # 保存修改
    success, err = add_user_handle.save_user_modify()
    if not success:
        logger.error(err)
        res.append(err)
        return res
    res.append("测试成功")
    return res


@program_exit
def test_change_group():
    """
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.选择任意一个新增的公开组用户的所在组下拉选项
    3.选中独立组选项
    4.点击保存按钮
    """

    res = ["""
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.选择任意一个新增的公开组用户的所在组下拉选项
    3.选中独立组选项
    4.点击保存按钮
    """]
    # 验证主任密钥
    success, err = check_leader_key()
    if not success:
        res.append(err)
        return res

    # 修改用户组
    success = add_user_handle.modify_group()
    if not success:
        res.append("修改用户组失败")
        err = add_user_handle.handle_cancel_modify()
        if err != "":
            logger.error(err)
        return res

    time.sleep(1)
    # 是否新建成功
    success, err = add_user_handle.operation_success()
    if success:
        logger.info("修改用户组成功")
    else:
        logger.error(err)
        res.append(err)
        err = add_user_handle.handle_cancel_modify()
        if err != "":
            logger.error(err)
        return res

    # 保存修改
    success, err = add_user_handle.save_user_modify()
    if not success:
        logger.error(err)
        res.append(err)
        return res
    res.append("测试成功")
    return res


@program_exit
def test_modify_user_name():
    """
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.选择任意一个新增用户点击操作修改名称
    3.输入任意名称后点击确定按钮
    4.点击保存按钮
    """

    res = ["""
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.选择任意一个新增用户点击操作修改名称
    3.输入任意名称后点击确定按钮
    4.点击保存按钮
    """]

    # 验证主任密钥
    success, err = check_leader_key()
    if not success:
        res.append(err)
        return res

    # 修改用户姓名
    success = add_user_handle.change_user_name()
    if success:
        success, err = add_user_handle.write_name(USER_NAME_PREFIX + datetime.now().strftime("%H%M%S"))
        if not success:
            logger.error(err)
            res.append(err)
            err = add_user_handle.handle_cancel_modify()
            if err != "":
                logger.error(err)
            return res

    time.sleep(0.5)
    # 是否修改成功
    success, err = add_user_handle.operation_success()
    if success:
        logger.info("修改用户名称成功")
    else:
        logger.error(err)
        res.append(err)
        err = add_user_handle.handle_cancel_modify()
        if err != "":
            logger.error(err)
        return res

    # 保存修改
    success, err = add_user_handle.save_user_modify()
    if not success:
        logger.error(err)
        res.append(err)
        return res
    res.append("测试成功")
    return res


@program_exit
def test_change_password():
    """
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.选择任意一个新增用户点击操作编辑手势密码
    3.修改绘制两次手势密码后
    4.点击保存按钮
    """

    res = ["""
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.选择任意一个新增用户点击操作编辑手势密码
    3.修改绘制两次手势密码后
    4.点击保存按钮
    """]

    # 验证主任密钥
    success, err = check_leader_key()
    if not success:
        res.append(err)
        return res

    # 修改密码
    success = add_user_handle.get_and_change_user_password()
    if success:
        # 绘制密码
        success = False
        while not success:
            success, err = drag_password(PASSWORD_INDEX)
            if not success and err != "":
                logger.error(err)
                res.append(err)
                err = add_user_handle.handle_cancel_modify()
                if err != "":
                    logger.error(err)
                return res

    time.sleep(1)
    # 是否修改密码成功
    success, err = add_user_handle.operation_success()
    if success:
        logger.info("修改密码成功")
    else:
        logger.error(err)
        res.append(err)
        err = add_user_handle.handle_cancel_modify()
        if err != "":
            logger.error(err)
        return res

    # 保存修改
    success, err = add_user_handle.save_user_modify()
    if not success:
        logger.error(err)
        res.append(err)
        return res
    res.append("测试成功")
    return res


@program_exit
def test_del_user():
    """
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.选择任意一个新增用户点击操作删除按钮
    3.点击确定按钮
    4.点击保存按钮
    """

    res = ["""
    1.插入主任密钥情况下点击“新建普通用户登录”按钮
    2.选择任意一个新增用户点击操作删除按钮
    3.点击确定按钮
    4.点击保存按钮
    """]

    # 验证主任密钥
    success, err = check_leader_key()
    if not success:
        res.append(err)
        return res

    # 删除用户
    success, pos_x, pos_y = add_user_handle.del_user()
    if success:
        success, err = add_user_handle.del_user_confirm(pos_x, pos_y)
        if not success:
            logger.error(err)
            res.append(err)
            err = add_user_handle.handle_cancel_modify()
            if err != "":
                logger.error(err)
            return res

    # 是否删除用户成功
    success, err = add_user_handle.operation_success()
    if success:
        logger.info("删除用户成功")
    else:
        logger.error(err)
        res.append(err)
        err = add_user_handle.handle_cancel_modify()
        if err != "":
            logger.error(err)
        return res

    # 保存修改
    success, err = add_user_handle.save_user_modify()
    if not success:
        logger.error(err)
        res.append(err)
        return res
    res.append("测试成功")
    return res


def run():

    # 新建用户
    test_create_user()

    time.sleep(2)
    # 修改用户组
    test_change_group()

    time.sleep(2)
    # 修改用户姓名
    test_modify_user_name()

    time.sleep(2)
    # 修改用户密码
    test_change_password()

    time.sleep(2)
    # 删除用户
    test_del_user()

    time.sleep(2)
    # 取消修改之保存
    test_cancel_modify(True)

    time.sleep(2)
    # 取消修改之取消
    test_cancel_modify(False)
