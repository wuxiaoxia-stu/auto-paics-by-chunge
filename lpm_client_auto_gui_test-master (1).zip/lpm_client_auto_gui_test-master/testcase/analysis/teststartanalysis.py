import os
import time
import logging
import random

from enum import Enum
import logging.config as logging_config

from setting import BASE_DIR
from controller.analysis.index import analysis_handle, ScreeningType, CaseType, CaseMultiF
from controller.common.play_control import play_control_handler, AiSwitch
from controller.common.common import program_exit, back_to_home
from controller.history.history_case import history_case_handle

from settings.log_config import my_log

if not os.path.exists(os.path.join(BASE_DIR, "log")):
    os.makedirs(os.path.join(BASE_DIR, "log"))

logging_config.dictConfig(my_log)
logger = logging.getLogger('testcase.analysis.teststartanalysis')


class SkipType(Enum):
    SkipDirect = 1  # 不等待倒计时，直接返回
    SkipAuto = 2  # 等待倒计时，自动返回
    SkipNot = 3  # 滚动使自动返回失效


def handle_stop_case_mark_page(skip_type, mark):
    """
    处理结束检查后的标记页
    :param skip_type: SkipType
    :param mark: 是否标记未带续接
    :return: success：操作是否成功
    :return: err：操作错误信息
    """

    if mark:  # 标记为待续接
        success, err = analysis_handle.mark_to_be_continue()
        if not success:
            logger.error(err)
        return success, err

    if skip_type == SkipType.SkipAuto:
        time.sleep(10)
        return True, ""
    elif skip_type == SkipType.SkipDirect:
        success, err = analysis_handle.skip_countdown()
        if not success:
            logger.error(err)
        return success, err
    else:
        analysis_handle.scroll_to_stop_skip()
        success, err = analysis_handle.skip_wait_continue()
        if not success:
            logger.error(err)
        return success, err


def handle_ai_switch(ai_switch_state):
    """
    处理切换播放器ai开关
    :param ai_switch_state: AiSwitch
    :return:
    """

    ai_position, ai_state, err = play_control_handler.get_ai_switch()
    if ai_position:
        if ai_switch_state != ai_state:
            play_control_handler.turn_ai_switch(ai_position)
    else:
        logger.error(err)
    return


def handel_screenshot(times):
    """
    处理截图，连续截图，间隔3s
    :param times: 截图张数
    :return:
    """

    while times > 0:
        success, err = play_control_handler.screenshot()
        if not success:
            logger.error(err)
        times -= 1
        play_control_handler.get_case_control()
        time.sleep(3)
    return


@program_exit
def test_start_single_case(skip_type, mark):
    """
    1.默认进入单胎弹窗页面
    2.点击选中任意一种筛查类型
    3.进入分析页面后等待大约3秒钟
    4.有ai截图3张，时间间隔3s
    5.无ai截图3张，时间间隔3s
    6.点击停止分析按钮
    7.不滑动列表等待倒计时结束
    :param skip_type: SkipType
    :param mark: 是否标记未带续接
    :return:
    """

    res = ["""
    1.默认进入单胎弹窗页面
    2.点击选中任意一种筛查类型
    3.进入分析页面后等待大约3秒钟
    4.有ai截图3张，时间间隔3s
    5.无ai截图3张，时间间隔3s
    6.点击停止分析按钮
    7.不滑动列表等待倒计时结束
    """]
    # 选择筛查A开始病例
    success, err = analysis_handle.start_analysis_by_screening_type(ScreeningType.TypeA)
    if not success:
        logger.error(err)
        res.append(err)
        return res

    time.sleep(3)

    # 有ai截图
    handle_ai_switch(AiSwitch.On)
    handel_screenshot(3)

    # 无ai截图
    handle_ai_switch(AiSwitch.Off)
    handel_screenshot(3)

    # 结束分析
    success, err = analysis_handle.stop_analysis()
    if not success:
        logger.error(err)
        res.append(err)
        return res

    # 处理结束检查后的标记页
    success, err = handle_stop_case_mark_page(skip_type, mark)
    if not success:
        res.append(err)
        return res

    res.append("新建单胎成功")
    return res


@program_exit
def test_start_multi_case(skip_type, mark):
    """
    1.点击选中多胎选项
    2.点击新建多胎F1病例
    3.正常结束病例后回到多胎弹窗
    4.点击新建多胎F2病例
    5.在多胎F2分析界面点击病例标记切换到多胎F1
    :param skip_type: SkipType
    :param mark: 是否标记未带续接
    :return:
    """

    res = ["""
    1.点击选中多胎选项
    2.点击新建多胎F1病例
    3.正常结束病例后回到多胎弹窗
    4.点击新建多胎F2病例
    5.在多胎F2分析界面点击病例标记切换到多胎F1
    """]
    # 选择开始多胎
    success, err = analysis_handle.select_start_case_type(CaseType.Multi)
    if not success:
        logger.error(err)
        res.append(err)
        return res

    # 开始多胎fn
    success, multi_f, err = analysis_handle.get_and_start_multi_case()
    if not success:
        logger.error(err)
        res.append(err)
        return res
    if multi_f == CaseMultiF.F1:  # 当开始f1时，选择筛查设置A
        success, err = analysis_handle.multi_case_select_screening(ScreeningType.TypeA)
        if not success:
            logger.error(err)
            res.append(err)
            return res

        time.sleep(random.randint(10, 100))

        # 结束分析
        success, err = analysis_handle.stop_analysis()
        if not success:
            logger.error(err)
            res.append(err)
            return res

        # 处理结束检查后的标记页
        success, err = handle_stop_case_mark_page(skip_type, mark)
        if not success:
            res.append(err)
            return res
        return test_start_multi_case(skip_type, mark)
    else:
        success, pos_x, pos_y, err = analysis_handle.is_have_else_multi_case()
        if not success:
            logger.error(err)
            # 结束分析
            success, err = analysis_handle.stop_analysis()
            if not success:
                logger.error(err)
                res.append(err)
                return res

            # 处理结束检查后的标记页
            success, err = handle_stop_case_mark_page(skip_type, mark)
            if not success:
                res.append(err)
                return res

        analysis_handle.switch_multi_case(CaseMultiF.F2, pos_x, pos_y)

        time.sleep(2)

        # 确定切换
        success, err = analysis_handle.switch_multi_case_confirm()
        if not success:
            logger.error(err)
            # 结束分析
            success, err = analysis_handle.stop_analysis()
            if not success:
                logger.error(err)
                res.append(err)
                return res

            # 处理结束检查后的标记页
            success = handle_stop_case_mark_page(skip_type, mark)
            if not success:
                res.append(err)
                return res

        time.sleep(3)
        # 退出病例
        success, err = history_case_handle.exit_case()
        if not success:
            logger.error(err)
            res.append(err)
            return res

        # 返回首页
        back_to_home()
        res.append("测试通过")
        return res


@program_exit
def test_start_continue_case(skip_type, mark):
    """
    1.默认进入单胎弹窗页面
    2.点击选中任意一种筛查类型
    3.进入分析页面后等待大约3秒钟
    4.点击停止分析按钮
    5.点击标记为续接
    6.点击选择续接选项
    7.进入分析页面后等待大约3秒钟
    8.点击停止分析按钮
    9.点击跳过等待界面
    :param skip_type: SkipType
    :param mark: 是否标记未带续接
    :return:
    """
    res = ["""
        1.默认进入单胎弹窗页面
        2.点击选中任意一种筛查类型
        3.进入分析页面后等待大约3秒钟
        4.点击停止分析按钮
        5.点击标记为续接
        6.点击选择续接选项
        7.进入分析页面后等待大约3秒钟
        8.点击停止分析按钮
        9.点击跳过等待界面
        """]
    time.sleep(2)
    # 选择筛查A开始病例
    success, err = analysis_handle.start_analysis_by_screening_type(ScreeningType.TypeA)
    if not success:
        logger.error(err)
        res.append(err)
        return res

    time.sleep(random.randint(10, 100))

    # 结束分析
    success, err = analysis_handle.stop_analysis()
    if not success:
        logger.error(err)
        res.append(err)
        return res

    # 标记为待续接
    success, err = analysis_handle.mark_to_be_continue()
    if not success:
        logger.error(err)
        res.append(err)
        return res

    # 选择续接开始病例
    success, err = analysis_handle.select_start_case_type(CaseType.Continue)
    if not success:
        logger.error(err)
        res.append(err)
        return res

    # 确定续接
    success, err = analysis_handle.start_continue_case_confirm()
    if not success:
        logger.error(err)
        res.append(err)
        return res

    time.sleep(random.randint(10, 100))

    # 结束分析
    success, err = analysis_handle.stop_analysis()
    if not success:
        logger.error(err)
        res.append(err)
        return res

    # 处理结束检查后的标记页
    success, err = handle_stop_case_mark_page(skip_type, False)
    if not success:
        res.append(err)
        return res

    res.append("测试成功")
    return res


def run():

    # 测试单胎
    test_start_single_case(SkipType.SkipAuto, False)

    # 测试多胎
    test_start_multi_case(SkipType.SkipDirect, False)

    # 测试续接病例
    test_start_continue_case(SkipType.SkipAuto, True)
