# _*_ coding: utf-8 _*_
# @Author   : mtnmmc
# @time     : 18-7-18 上午10:18
# @file     : log_config.py

import os

from datetime import datetime

from setting import BASE_DIR

my_log = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'standard': {
            'format': '[%(asctime)s] [%(levelname)s] [%(name)s:%(lineno)d] [%(module)s:%(funcName)s] - %(message)s',
            # 日志格式
            "datefmt": "%Y-%m-%d %H:%M:%S"
        }, 'simple': {
            'format': '[%(asctime)s] %(levelname)s [%(module)s:%(funcName)s] - %(message)s',
            "datefmt": "%Y-%m-%d %H:%M:%S"
        }
    },
    'filters': {
    },
    'handlers': {
        'console': {
                    'level': 'INFO',
                    'class': 'logging.StreamHandler',
                    'formatter': 'simple'
                },
        # 'info': {
        #     'level': 'INFO',
        #     'class': 'logging.handlers.RotatingFileHandler',
        #     'filename': os.path.join(BASE_DIR, 'log/info' + datetime.now().strftime("%Y%m%d") + '.log'),  # 日志输出文件
        #     'maxBytes': 1024 * 1024 * 5,  # 文件大小
        #     'backupCount': 5,  # 备份份数
        #     'formatter': 'simple',  # 使用哪种formatters日志格式
        # },
        'error': {
            'level': 'ERROR',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(BASE_DIR, 'log/error' + datetime.now().strftime("%Y%m%d") + '.log'),
            'maxBytes': 1024 * 1024 * 5,
            'backupCount': 5,
            'formatter': 'standard',
        }
    },
    'loggers': {
        'testcase.index.testswitchuser': {
            'handlers': ['error'],
            'level': 'ERROR',
            'propagate': False
        },
        'testcase.user.testeditusergroup': {
            'handlers': ['error'],
            'level': 'ERROR',
            'propagate': False
        },
        'testcase.analysis.teststartanalysis': {
            'handlers': ['error'],
            'level': 'ERROR',
            'propagate': False
        }
    },
}
